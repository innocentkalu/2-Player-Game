require 'pry'
require 'colorize'

# Defining the player clasa
class Player

  attr_accessor :name, :score, :lives

  def initialize(name,score,lives)
    @name = name
    @score = score
    @lives = lives
  end

end

class Game

  attr_accessor :ans, :question
  def initialize
    @random = rand(3)
    @a = rand(20).to_f
    @b = rand(20).to_f
      case @random
        when 0 
          @ans = @a + @b
          @question = "what is #{@a} + #{@b}"
        when 1 
          @ans = @a - @b
          @question = "what is #{@a} - #{@b}"
        else 
          @ans = (@a / (@b+1))
          @question = "what is #{@a} / #{@b}"
        end
  end
end


# Initialize variables
puts " Welcome! You have three lives and will lose a life with each incorrect answer. The game ends when \
one player runs out of lives and the player still alive wins."

puts " Player 1, please provide your name"
player1 = gets.chomp.downcase
puts " Player 2, please provide your name"
player2 = gets.chomp.downcase
  
p1 = Player.new(player1,0,3)
p2= Player.new(player2,0,3)

# Gaming loop
game_play = true

x = 1
while game_play
binding.pry
  new_turn = Game.new
  question = new_turn.question
  answer = new_turn.ans
binding.pry

  x.odd? ? gamer = p1 : gamer = p2
  if (p1.lives<1) || (p2.lives<1)
      if p1.lives > p2.lives
        puts "#{p2.name} has no lives left so #{p1.name} wins!!!".green
      else
        puts "#{p1.name} has no lives left so #{p2.name} wins!!!".green
      end
      game_play = false
  else
    puts "#{gamer.name} #{question}?"
    gamer_ans = gets.chomp.to_f
    if gamer_ans == answer
      gamer.score +=1
    else
      gamer.lives -=1
      puts "#{p1.name} has #{p1.lives} lives left and #{p2.name} has #{p2.lives} lives left".red
    end
  end

  x +=1
  game_play = (game_play == false)? false : true


end
 